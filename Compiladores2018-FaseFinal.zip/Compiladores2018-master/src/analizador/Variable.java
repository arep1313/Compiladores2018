/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analizador;

import java.util.ArrayList;

/**
 *
 * @author betic
 */
public class Variable extends Simbolo{
    
    ArrayList<String> Valores = new ArrayList<String>();
    public Variable(type tipo,String id)//, String ambito)
    {
        super(tipo,id);//,ambito);
    }
    @Override public String value()
    {
        return Valores.get(Valores.size()-1);
    } 
    @Override public void addValue(String valor)
    {
        Valores.add(valor);
    }
    
}
