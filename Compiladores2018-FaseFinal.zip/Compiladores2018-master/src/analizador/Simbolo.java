/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analizador;

/**
 *
 * @author betic
 */
public abstract class Simbolo {
    public type Tipo;
    public String Id;
    public String Ambito;
    public Simbolo(type tipo,String id)
    {
        Tipo = tipo;
        Id = id;
        //Ambito = ambito;
    }
    public String value()
    {
        return null;
    }
    public void addValue(String valor)
    {
        
    }
    @Override public boolean equals(Object x)
    {
        if (this == x) return true;
        if(x instanceof String) return (this.Id.equals(x));
        if (!(x instanceof Simbolo)) return false;
        Simbolo other = (Simbolo)x;
        if(other.Id.equals(this.Id) & other.Ambito.equals(this.Ambito)) return true;
        return true;
    }
    public boolean Compatibles(Object x)
    {
        if(this == x) return true;
        if(!(x instanceof Variable)) return false;
        Variable other = (Variable)x;
        if(other.Tipo.equals(this.Tipo)) return true;
        if((other.Tipo.equals(type.integer)|other.Tipo.equals(type.Double))&(this.Tipo.equals(type.Double)|(this.Tipo.equals(type.integer)))) return true;
        return true;
    }
}