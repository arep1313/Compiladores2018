/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package analizador;

import java.io.File;

/**
 *
 * @author Carlos
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //String path = "C:\\Users\\betic\\Documents\\URL\\8vo Ciclo\\Compiladores\\analizadorLexico2-Java\\src\\analizador\\Lexer.flex";
        String path = "C:\\Users\\betic\\Documents\\URL\\8vo Ciclo\\Compiladores2018-master\\src\\analizador\\minicsharp.flex";
        generarLexer(path);
        path = "C:\\Users\\betic\\Documents\\URL\\8vo Ciclo\\Compiladores2018-master\\src\\analizador\\asintactico.cup";
        generarCup(path);
    
    }
    public static void generarLexer(String path){
        File file=new File(path);
        JFlex.Main.generate(file);
    }
    public static void generarCup(String path){
        String archSintactico = path;
        try
        {
            String[] asintactico = {"-parser", "AnalizadorSintactico", archSintactico};
            java_cup.Main.main(asintactico);
        }
        catch(Exception ex)
        {
            System.out.println("GG, no lo proceso. ");
        }
    }
}
