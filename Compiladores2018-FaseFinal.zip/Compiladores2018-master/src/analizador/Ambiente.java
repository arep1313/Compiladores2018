/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analizador;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author betic
 */
public class Ambiente {
 
    ArrayList<Simbolo> Simbolos = new ArrayList<Simbolo>();
    ArrayList<String> Errores = new ArrayList<String>();
    public void addToTableN(Simbolo nueva)
    {
        if(Simbolos.contains(nueva))
        {
            Errores.add("Esta variable ya ha sido declarada: " + nueva.Id);
            //Simbolos.get(Variables.indexOf(nueva)).addValue(nueva.value());
        }
        else
        {
            Simbolos.add(nueva);
        }
    }
    public void addValue(Simbolo nueva)
    {
        if(Simbolos.contains(nueva))
        {
            Simbolos.get(Simbolos.indexOf(nueva)).addValue(nueva.value());
        }
        else
        {
            Errores.add("Esta variable ya ha sido declarada: " + nueva.Id);
        }
    }
    public void ImprimirTabla()
    {
        try
        {
            String path = "";
            FileWriter fw = new FileWriter(path);
            BufferedWriter BW = new BufferedWriter(fw);
            BW.write("TIPO | ID | VALOR | MODO");
            for (int i = 0; i < Simbolos.size(); i++) {
                BW.write(Simbolos.get(i).Tipo.toString()+Simbolos.get(i).Id+Simbolos.get(i).value()+Simbolos.get(i).getClass().toString());
            }
            
            
        }
        catch(IOException ex)
        {
            
        }
    }
    public String GetValue(String id)
    {
        if(Simbolos.contains(id))
        {
            if(Simbolos.get(Simbolos.indexOf(id)) instanceof Variable)
            return Simbolos.get(Simbolos.indexOf(id)).value();
            else
            {
                System.out.println("Este simbolo: "+id+" no es una variable declarada");
                return "0";
            }
        }
        else
        {
            System.out.println("Esta simbolo no ha sido declarado: " + id + "se asignara 0 a su instancia. ");
            return "0";
        }
    }
    
}
