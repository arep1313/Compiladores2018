/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package analizador;

/**
 *
 * @author Carlos
 */
public enum type {
    string, integer,Double,bool,id,Class,Void,Interface,notype
}
